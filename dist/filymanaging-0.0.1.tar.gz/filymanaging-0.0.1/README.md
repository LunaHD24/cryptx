# FilyManaging
**FilyManaging** is an easy to use file manager tool for python 3.11 and higher.

## How to install
**Windows**
´´´
py -m pip install git+https://github.com/LunaHD24/FilyManaging.git#egg=FilyManaging
´´´

**Unix/MacOS**
´´´
python3 -m pip install git+https://github.com/LunaHD24/FilyManaging.git#egg=FilyManaging
´´´

## Documentation


### Get started

